/* ==========================================================================
   DEMO DATASET — synthetic, deterministic, clearly labelled DEMO DATA.
   Generated at the same grains Amazon reports (campaign, placement,
   targeting, search term, advertised product) and reconciled so every
   grain sums to the same campaign totals.
   Brands, ASINs and campaigns are fictional.
   ========================================================================== */
const DemoData = (() => {
  const START = Dates.dayOf(2025, 0, 1), END = Dates.dayOf(2026, 8, 22);

  function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }

  const CATALOG = {
    B0VELT0001: ["Veltra Women's Jogger Scrub Pant", 'Veltra', 'Scrub Pants', 'Active'],
    B0VELT0002: ["Veltra Women's Utility Scrub Top", 'Veltra', 'Scrub Tops', 'Active'],
    B0VELT0003: ["Veltra Men's Straight-Leg Scrub Pant", 'Veltra', 'Scrub Pants', 'Active'],
    B0VELT0004: ["Veltra Men's V-Neck Scrub Top", 'Veltra', 'Scrub Tops', 'Out of Stock'],
    B0VELT0005: ["Veltra Women's Stretch Scrub Set", 'Veltra', 'Scrub Sets', 'Active'],
    B0VELT0010: ["Veltra Women's Cargo Scrub Pant", 'Veltra', 'Scrub Pants', 'Active'],
    B0CFLX0006: ["CareFlex Women's Fleece Scrub Jacket", 'CareFlex', 'Jackets', 'Active'],
    B0CFLX0007: ["CareFlex Men's Softshell Scrub Jacket", 'CareFlex', 'Jackets', 'Suppressed'],
    B0NSHF0008: ['NightShift Graduated Compression Socks, 3-Pack', 'NightShift', 'Accessories', 'Active'],
    B0NSHF0009: ['NightShift Retractable Badge Reel', 'NightShift', 'Accessories', 'Inactive'],
  };

  // [name, adType, campaignType, portfolio, weight, cpc, ctr%, cvr%, aov, targets:[[text, match, kwType]], asins]
  const E = 'Exact', P = 'Phrase', B = 'Broad', A = 'Auto';
  const CAMPAIGNS = [
    ['Brand Defense – Exact', 'SP', 'SP Manual', 'Brand Defense', 1.4, 0.55, 1.6, 16.5, 34, [['veltra scrubs', E, 'Branded'], ['veltra scrub pants', E, 'Branded'], ['veltra', E, 'Branded']], ['B0VELT0001', 'B0VELT0002', 'B0VELT0005']],
    ['Brand – Phrase', 'SP', 'SP Manual', 'Brand Defense', 0.6, 0.6, 1.2, 14, 33, [['veltra scrubs women', P, 'Branded'], ['veltra jogger scrubs', P, 'Branded']], ['B0VELT0001', 'B0VELT0010']],
    ['Core Pants – Exact', 'SP', 'SP Manual', 'Core Scrubs', 1.3, 0.92, 0.8, 12.5, 31, [['scrub pants women', E, 'Generic'], ['black scrub pants', E, 'Generic'], ['jogger scrub pants', E, 'Generic']], ['B0VELT0001', 'B0VELT0003', 'B0VELT0010']],
    ['Core Tops – Exact', 'SP', 'SP Manual', 'Core Scrubs', 1.1, 0.88, 0.78, 12, 27, [['womens scrub top', E, 'Generic'], ['scrub tops for women', E, 'Generic'], ['v neck scrub top', E, 'Generic']], ['B0VELT0002', 'B0VELT0004']],
    ['Core Scrubs – Broad', 'SP', 'SP Manual', 'Core Scrubs', 0.9, 0.78, 0.6, 9.5, 30, [['nursing scrubs', B, 'Generic'], ['medical scrubs', B, 'Generic']], ['B0VELT0001', 'B0VELT0002', 'B0VELT0005']],
    ['Category Discovery – Phrase', 'SP', 'SP Manual', 'Core Scrubs', 0.8, 0.84, 0.66, 10.5, 32, [['medical scrubs women', P, 'Generic'], ['scrubs for nurses', P, 'Generic'], ['scrub sets women', P, 'Generic']], ['B0VELT0005', 'B0VELT0010']],
    ['Auto – Close Match', 'SP', 'SP Auto', 'Core Scrubs', 0.9, 0.62, 0.55, 10.8, 29, [['close-match', A, 'Auto'], ['substitutes', A, 'Auto']], ['B0VELT0001', 'B0VELT0002', 'B0VELT0003']],
    ['Auto – Loose Match', 'SP', 'SP Auto', 'Core Scrubs', 0.5, 0.48, 0.42, 8.2, 28, [['loose-match', A, 'Auto'], ['complements', A, 'Auto']], ['B0VELT0003', 'B0VELT0004']],
    ['Jackets – Exact', 'SP', 'SP Manual', 'Outerwear', 0.5, 0.95, 0.7, 10, 46, [['scrub jacket women', E, 'Generic'], ['nurse jacket', E, 'Generic']], ['B0CFLX0006', 'B0CFLX0007']],
    ['Outerwear – Auto', 'SP', 'SP Auto', 'Outerwear', 0.35, 0.6, 0.45, 8.5, 44, [['close-match', A, 'Auto'], ['substitutes', A, 'Auto']], ['B0CFLX0006']],
    ['Accessories – Broad', 'SP', 'SP Manual', 'Accessories', 0.3, 0.52, 0.5, 11, 19, [['compression socks nurses', B, 'Generic'], ['badge reel', B, 'Generic']], ['B0NSHF0008', 'B0NSHF0009']],
    ['Competitor ASIN Targeting', 'SP', 'SP Manual', 'Competitor Conquest', 0.6, 0.74, 0.35, 7.2, 31, [['asin="B0HALD2231"', 'Product', 'Competitor'], ['asin="B0CRWL7781"', 'Product', 'Competitor']], ['B0VELT0001', 'B0VELT0002']],
    ['Competitor Keywords – Phrase', 'SP', 'SP Manual', 'Competitor Conquest', 0.45, 1.05, 0.45, 5.4, 30, [['halden scrubs', P, 'Competitor'], ['carewell scrubs', P, 'Competitor']], ['B0VELT0001', 'B0VELT0005']],
    ['SB – Store Spotlight', 'SB', 'SB Store Spotlight', 'Brand Defense', 0.35, 0.7, 2.1, 13, 38, [['veltra', E, 'Branded']], ['B0VELT0001', 'B0VELT0002', 'B0VELT0005']],
    ['SB – Video Core Pants', 'SB', 'SB Video', 'Core Scrubs', 0.5, 0.82, 0.9, 9.8, 32, [['scrub pants', B, 'Generic'], ['jogger scrubs', P, 'Generic']], ['B0VELT0001', 'B0VELT0010']],
    ['SB – Collection Tops', 'SB', 'SB Product Collection', 'Core Scrubs', 0.4, 0.8, 0.8, 9, 28, [['scrub tops', B, 'Generic'], ['womens scrubs', P, 'Generic']], ['B0VELT0002', 'B0VELT0004']],
    ['SD – Views Remarketing', 'SD', 'SD Audiences', 'Core Scrubs', 0.35, 0.58, 0.28, 8.8, 31, [['views=(similar to advertised 30d)', 'Audience', 'Audience']], ['B0VELT0001', 'B0VELT0005']],
    ['SD – Contextual Competitor', 'SD', 'SD Contextual', 'Competitor Conquest', 0.3, 0.5, 0.22, 4.9, 30, [['category="Medical Scrubs"', 'Product', 'Contextual']], ['B0VELT0002', 'B0VELT0003']],
  ];
  const MARKETS = [
    { mk: 'US', unit: 950, fx: 1, price: 1, accounts: p => (p === 'Outerwear' || p === 'Accessories') ? 'Scrubwear Outfitters' : 'Scrubwear Media', pick: null },
    { mk: 'UK', unit: 210, fx: 0.79, price: 1, accounts: () => 'Scrubwear Media UK', pick: [0, 2, 3, 5, 6, 8, 13, 16] },
    { mk: 'IN', unit: 260, fx: 83, price: 0.32, accounts: () => 'Scrubwear Media India', pick: [0, 2, 3, 4, 6, 7, 10, 14] },
  ];
  const MODIFIERS = ['', ' plus size', ' for women', ' petite', ' cheap', ' tall', ' set', ' men'];
  const AUTO_TERMS = ['scrubs women', 'scrub pants', 'nurse scrubs set', 'b0hald2231', 'womens joggers scrubs', 'medical uniforms', 'cheap scrubs', 'scrub top pockets'];

  function placementsFor(adType, campaign) {
    if (adType === 'SB') return [['Top of Search', 0.7, 1.15, 1.2, 1.15], ['Rest of Search', 0.3, 0.85, 0.7, 0.85]];
    if (adType === 'SD') return [['Product Pages', 0.72, 1, 1.1, 1.05], ['Off-Amazon', 0.28, 0.8, 0.5, 0.7]];
    if (/Brand/.test(campaign)) return [['Top of Search', 0.62, 1.15, 1.4, 1.12], ['Rest of Search', 0.23, 0.95, 0.8, 0.92], ['Product Pages', 0.15, 0.8, 0.45, 0.78]];
    if (/ASIN/.test(campaign)) return [['Top of Search', 0.1, 1.2, 1.2, 1.1], ['Rest of Search', 0.15, 1, 0.9, 1], ['Product Pages', 0.75, 0.9, 1, 0.95]];
    if (/Auto/.test(campaign)) return [['Top of Search', 0.25, 1.2, 1.5, 1.2], ['Rest of Search', 0.3, 1, 0.9, 0.95], ['Product Pages', 0.45, 0.82, 0.6, 0.85]];
    return [['Top of Search', 0.45, 1.22, 1.5, 1.2], ['Rest of Search', 0.33, 0.95, 0.8, 0.88], ['Product Pages', 0.22, 0.78, 0.45, 0.72]];
  }

  function seasonality(d) {
    const [y, m, dd] = Dates.ymd(d);
    const growth = 1 + 0.24 * (d - START) / 365;
    const month = [0.88, 0.9, 1, 1, 1.02, 0.98, 1.05, 1.08, 1.1, 1.06, 1.25, 1.18][m];
    let event = 1;
    if (y === 2025 && m === 6 && dd >= 8 && dd <= 11) event = 2.1;   // Prime Day 2025
    if (y === 2026 && m === 6 && dd >= 14 && dd <= 17) event = 2.2;  // Prime Day 2026
    if (m === 10 && dd >= 25) event = 1.7;                            // BFCM
    const wd = [1.05, 1.08, 1.02, 1, 0.98, 0.92, 0.95][Dates.weekday(d)];
    return growth * month * event * wd;
  }

  /* Split a totals object across parts, reconciling exactly. part: {w, cpc, ctr, cvr, aov} multipliers */
  const INT = new Set(Config.BASE_METRICS.filter(m => m.fmt === 'int').map(m => m.key));
  function split(tot, parts, skip) {
    const wc = parts.map(p => p.w / p.cpc);
    const weights = {
      adSpend: parts.map(p => p.w), clicks: wc, impressions: parts.map((p, i) => wc[i] / p.ctr),
      orders: parts.map((p, i) => wc[i] * p.cvr), adSales: parts.map((p, i) => wc[i] * p.cvr * p.aov),
    };
    weights.units = weights.orders; weights.ntbOrders = weights.orders;
    weights.sameSkuSales = weights.otherSkuSales = weights.ntbSales = weights.adSales;
    weights.dpv = weights.clicks; weights.videoViews = weights.viewableImpressions = weights.engagements = weights.impressions;
    const out = parts.map(() => ({}));
    for (const key of Object.keys(tot)) {
      const v = tot[key];
      if (v == null || skip.includes(key)) { out.forEach(o => { o[key] = null; }); continue; }
      const w = weights[key] || weights.adSpend;
      const sw = w.reduce((a, b) => a + b, 0) || 1;
      let cum = 0, prev = 0;
      for (let i = 0; i < parts.length; i++) {
        cum += v * w[i] / sw;
        if (INT.has(key)) { const r = Math.round(cum); out[i][key] = r - prev; prev = r; }
        else out[i][key] = i === parts.length - 1 ? v - prev : +(v * w[i] / sw).toFixed(2), prev += out[i][key];
      }
    }
    return out;
  }

  function generate() {
    const r = rng(20260922);
    const fileId = 'demo';
    const T = DataStore.tables;
    let rows = 0;
    for (const M of MARKETS) {
      const camps = M.pick ? M.pick.map(i => CAMPAIGNS[i]) : CAMPAIGNS;
      for (const C of camps) {
        const [name, adType, campaignType, portfolio, weight, cpc0, ctr0, cvr0, aov0, targets, asins] = C;
        const dims = { marketplace: M.mk, account: M.accounts(portfolio), adType, campaignType, portfolio, campaign: name,
          targeting: campaignType === 'SP Auto' ? 'Auto' : 'Manual', fileId };
        const places = placementsFor(adType, name);
        const constrained = /Brand Defense/.test(name);
        for (let d = START; d <= END; d++) {
          const recent = Math.max(0, Math.min(1, (d - (END - 120)) / 120)); // 0 → 1 over last 120 days
          const progress = (d - START) / (END - START);
          let vol = seasonality(d) * (0.88 + r() * 0.24);
          let cvrM = 0.94 + r() * 0.12, cpcM = 0.95 + r() * 0.1, ctrM = 0.94 + r() * 0.12;
          if (name === 'Category Discovery – Phrase') cvrM *= 1 - 0.3 * recent;
          if (name === 'Jackets – Exact') { cvrM *= 1 + 0.35 * recent; const m = Dates.ymd(d)[1]; if (m >= 9 || m <= 1) vol *= 1.45; }
          if (name === 'Competitor Keywords – Phrase') vol *= 1 + 0.6 * progress;
          if (name === 'Auto – Loose Match') cpcM *= 1 + 0.2 * recent;
          const cpc = cpc0 * cpcM * M.fx * M.price;
          let spend = M.unit * weight * vol * M.fx * M.price;
          const clicks = Math.max(0, Math.round(spend / cpc));
          spend = +(clicks * cpc).toFixed(2);
          const impressions = Math.round(clicks / (ctr0 * ctrM / 100));
          const orders = Math.floor(clicks * cvr0 * cvrM / 100 + r());
          const units = orders + Math.floor(orders * 0.08 + r());
          const sales = +(orders * aov0 * M.fx * M.price * (0.92 + r() * 0.16)).toFixed(2);
          const tot = { adSpend: spend, adSales: sales, impressions, clicks, orders, units,
            dpv: null, sameSkuSales: null, otherSkuSales: null, ntbOrders: null, ntbSales: null, incrementalSales: null,
            budget: null, reach: null, videoViews: null, viewableImpressions: null, engagements: null, tosIs: null, searchIs: null };
          if (adType === 'SP') { const same = +(sales * (0.78 + r() * 0.08)).toFixed(2); tot.sameSkuSales = same; tot.otherSkuSales = +(sales - same).toFixed(2); }
          if (adType !== 'SP') {
            tot.dpv = Math.round(clicks * (1.4 + r() * 0.3));
            tot.ntbOrders = Math.round(orders * (0.3 + r() * 0.18));
            tot.ntbSales = +(tot.ntbOrders * aov0 * M.fx * M.price).toFixed(2);
            tot.viewableImpressions = Math.round(impressions * (0.58 + r() * 0.1));
            tot.videoViews = campaignType === 'SB Video' || adType === 'SD' ? Math.round(impressions * (0.12 + r() * 0.08)) : 0;
          }
          if (adType === 'SD') { tot.engagements = Math.round(clicks * (0.35 + r() * 0.1)); }
          const camp = { ...tot, budget: +(M.unit * weight * seasonality(d) * M.fx * M.price * (constrained ? 1.02 : 1.35)).toFixed(2) };
          if (adType === 'SP') camp.tosIs = +(constrained ? 62 + r() * 18 : 9 + r() * 22).toFixed(2);
          if (adType === 'SD') camp.reach = Math.round(impressions / (2.1 + r() * 0.5));
          T.campaign.push(d, dims, camp); rows++;

          // placements (TOS share drifts up over time → placement shift insight)
          const pl = places.map(([p, w, cpcm, ctrm, cvrm]) => ({ name: p, w: w * (p === 'Top of Search' ? 1 + 0.25 * progress : 1) * (0.9 + r() * 0.2), cpc: cpcm, ctr: ctrm, cvr: cvrm, aov: 1 }));
          split(tot, pl, ['tosIs', 'searchIs']).forEach((m, i) => { T.placement.push(d, { ...dims, placement: pl[i].name }, m); rows++; });

          // targeting
          const tg = targets.map(([k], i) => { const h = hash(k + name); return { w: (1 + (h % 7) / 4) * (0.85 + r() * 0.3), cpc: 0.85 + (h % 5) / 10, ctr: 1, cvr: 0.75 + ((h >> 3) % 6) / 10, aov: 1 }; });
          const tRows = split(tot, tg, ['tosIs', 'searchIs']);
          tRows.forEach((m, i) => {
            const [kw, match, kwType] = targets[i];
            const kd = { ...dims, keyword: kw, matchType: match, keywordType: kwType };
            T.keyword.push(d, kd, m); rows++;
            if (adType === 'SD' || match === 'Product') return;
            // search terms for this target
            const base = match === 'Auto' ? AUTO_TERMS.filter((_, j) => (hash(kw) >> j) & 1).slice(0, 3) : [kw, kw + MODIFIERS[1 + hash(kw) % 7]];
            const st = base.map(s => { const h = hash(s + kw); const cheap = / cheap|b0hald/.test(s); return { term: s, w: 0.6 + (h % 9) / 6, cpc: 1, ctr: 0.8 + (h % 4) / 8, cvr: cheap ? 0.12 : 0.7 + ((h >> 4) % 7) / 10, aov: 1 }; });
            split(m, st, ['tosIs', 'searchIs']).forEach((sm, j) => {
              sm.searchIs = adType === 'SP' ? +(4 + (hash(st[j].term) % 30) + r() * 4).toFixed(2) : null;
              T.searchTerm.push(d, { ...kd, searchTerm: st[j].term }, sm); rows++;
            });
          });

          // advertised products
          const ap = asins.map(a => { const h = hash(a + name); const oos = CATALOG[a][3] === 'Out of Stock' && d > END - 18; const supp = CATALOG[a][3] === 'Suppressed'; return { w: (1 + (h % 5) / 3) * (supp ? 0.25 : 1), cpc: 1, ctr: 1, cvr: (0.8 + (h % 5) / 10) * (oos ? 0.12 : 1), aov: 1 }; });
          split(tot, ap, ['tosIs', 'searchIs']).forEach((m, i) => {
            const a = asins[i], [title, brand, category, status] = CATALOG[a];
            T.asin.push(d, { ...dims, asin: a, title, brand, category, asinStatus: status }, m); rows++;
          });
        }
      }
    }
    const b = DataStore.bounds();
    DataStore.registerFile({ id: fileId, name: 'Demo dataset (synthetic)', source: 'all', rows, minDay: b.min, maxDay: b.max, importedAt: Date.now(), demo: true });
    DataStore.isDemo = true;
  }
  return { generate };
})();
